package com.ojas.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.Data;

@Data
@Entity
@Table(name="BOOK")
public class BookEntity {

	@Id
	@Column(name="BID")
	@GenericGenerator(name="myGenerator",strategy = "increment")
	@GeneratedValue(generator = "myGenerator",strategy = GenerationType.AUTO)
	private Integer bid;
	@Column(name="BNAME")
	private String bname;
	@Column(name="BAUTHORNAME")
	private String bauthor;
	@Column(name="BTYPE")
	private String btype;
	@Column(name="BPRICE")
	private double bprice;
	
}
