package com.ojas.demo.service;

import java.util.List;

import com.ojas.demo.binding.Book;



public interface BookService {

	public boolean saveBook(Book book);
	public List<Book> getAllBooks();
	public Book getBookById(int id);
	public boolean updateBook(Book bk);
	public void deleteBook(int id);
}
