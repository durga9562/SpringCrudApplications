package com.ojas.demo.binding;

import lombok.Data;

@Data
public class Book {

	private Integer bid;
	private String bname;
	private String bauthor;
	private String btype;
	private double bprice;
}
