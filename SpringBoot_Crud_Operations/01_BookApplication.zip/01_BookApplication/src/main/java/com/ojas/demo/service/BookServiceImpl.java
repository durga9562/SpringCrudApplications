package com.ojas.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ojas.demo.binding.Book;
import com.ojas.demo.entity.BookEntity;
import com.ojas.demo.repository.BookRepository;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository bookR;
	
	
	@Override
	public boolean saveBook(Book book) {
		
		
		BookEntity be = new BookEntity();
		/*
		 * be.setBid(book.getBid()); be.setBname(book.getBname());
		 * be.setBauthor(book.getBauthor()); be.setBtype(book.getBtype());
		 * be.setBprice(book.getBprice()); BookEntity savebook = bookR.save(be);
		 */
		 
		
		BeanUtils.copyProperties(book, be);
		BookEntity savebook = bookR.save(be);
		if(savebook != null)
			return true;
		return false;
	}

	@Override
	public List<Book> getAllBooks() {
		List<BookEntity> getbooks = bookR.findAll();
		List<Book> viewBooks = new ArrayList<>();
		for(BookEntity ben : getbooks) {
			Book b = new Book();
			BeanUtils.copyProperties(ben, b);
			viewBooks.add(b);
		}
		return viewBooks;
	}

	@Override
	public Book getBookById(int id) {
		Optional<BookEntity> findById = bookR.findById(id);
		BookEntity bentity= findById.get();
		Book book=new Book();
		BeanUtils.copyProperties(bentity, book);
		return book;
	}

	@Override
	public boolean updateBook(Book bk) {
	BookEntity bookEnty = bookR.findById(bk.getBid()).get();
	BeanUtils.copyProperties(bk, bookEnty);
	BookEntity save = bookR.save(bookEnty);
	if(save != null){
		return true;
	}
		return false;
	}

	@Override
	public void deleteBook(int id) {
		bookR.deleteById(id);

	}

}
